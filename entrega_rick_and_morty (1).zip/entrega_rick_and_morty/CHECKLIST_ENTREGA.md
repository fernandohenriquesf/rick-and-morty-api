# Checklist final da entrega

## Entregáveis preparados
- [x] Projeto prático com HTML, CSS e JavaScript em pastas separadas.
- [x] README com instruções de execução e publicação.
- [x] PDF teórico sobre API, DOM, Fetch, escolha da API e estrutura dos dados.
- [x] Roteiro para vídeo pitch de até 4 minutos.

## Ações que você ainda precisa fazer
- [ ] Abrir e testar `projeto-rick-and-morty/index.html` com internet.
- [ ] Compactar/enviar o projeto (o ZIP incluído já está pronto).
- [ ] Criar repositório no GitHub e enviar os arquivos.
- [ ] Publicar com GitHub Pages e copiar o link real.
- [ ] Gravar e publicar o vídeo pitch e copiar o link real.

Importante: não é possível afirmar que o site está publicado nem fornecer links reais do GitHub ou do vídeo antes que você faça essas publicações.
