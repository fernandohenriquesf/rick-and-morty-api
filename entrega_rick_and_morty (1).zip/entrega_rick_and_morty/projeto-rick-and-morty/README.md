# Rick & Morty — Multiverse Explorer

Projeto acadêmico de front-end que consome a API pública Rick and Morty.

## Tecnologias
- HTML5
- CSS3
- JavaScript Vanilla (ES6+)
- Fetch API e async/await

Não utiliza frameworks nem bibliotecas externas.

## Como executar
1. Extraia a pasta `projeto-rick-and-morty`.
2. Abra `index.html` no navegador.
3. Mantenha uma conexão com a internet para carregar os dados da API.

Se preferir, abra a pasta no VS Code e execute com a extensão Live Server.

## Funcionalidades
- Cards criados dinamicamente a partir da API.
- Busca por nome e filtro por status.
- Carregamento paginado com botão “Carregar mais”.
- Modal com origem, localização, espécie, gênero e episódios.
- Estados de carregamento e mensagens de erro.
- Layout responsivo com tema escuro e cores neon.

## API
Endpoint base: https://rickandmortyapi.com/api/character

A API pública pode ser consultada sem chave/token neste projeto. A resposta contém `info` (paginação) e `results` (personagens). Cada personagem inclui campos como `name`, `status`, `species`, `image`, `origin`, `location` e `episode`.

## Publicação no GitHub
1. Crie um repositório público no GitHub, por exemplo `rick-and-morty-explorer`.
2. Envie os arquivos desta pasta mantendo as pastas `css` e `js`.
3. Para publicar pelo GitHub Pages: abra **Settings → Pages**, selecione a branch `main` e a pasta `/ (root)`, e salve.
4. Aguarde a publicação e teste o endereço informado pelo GitHub.

## Demonstração técnica
Abra as ferramentas do navegador com F12:
- **Network/Rede**: filtre por `character` para mostrar as requisições da API.
- **Sources/Fontes**: abra `js/script.js` e mostre `fetch`, `createElement` e `appendChild`.
- **Elements/Elementos**: expanda `#charactersGrid` para mostrar que os cards aparecem dinamicamente.

## Observação
O projeto depende de conexão com a internet para consultar a API e carregar imagens.
